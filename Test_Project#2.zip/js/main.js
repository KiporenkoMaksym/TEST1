const Burger = document.querySelector('.burger_menu');
const menu = document.querySelector('.menu_btn');
Burger.addEventListener('click', function() {
    document.body.classList.toggle(`lock`);
    menu.classList.toggle('btn_block');
    Burger.classList.toggle('active_btn')
}
)